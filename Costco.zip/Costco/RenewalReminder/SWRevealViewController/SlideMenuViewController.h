//
//  SlideMenuViewController.h
//  RenewalReminder
//
//  Created by MonuRathor on 01/02/15.
//  Copyright (c) 2015 MonuRathor. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SlideMenuViewController : UITableViewController

@end
